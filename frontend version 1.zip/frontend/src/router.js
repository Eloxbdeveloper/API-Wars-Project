import { renderHome } from './pages/home.js';
import { renderDashboard } from './pages/dashboard.js';
import { placeholderPage } from './pages/placeholder.js';
import { setActiveNav } from './components/nav.js';

// Alcance actual: Inicio, Dashboard, Facturas y Notas crédito.
// Cuando el integrante 3 tenga sus páginas, solo cambia el valor de su ruta.
const routes = {
  '/': renderHome,
  '/dashboard': renderDashboard,
  '/facturas': placeholderPage('Facturas'),
  '/facturas/nueva': placeholderPage('Nueva factura', 'Aquí irá el paso a paso para crear y emitir la factura.'),
  '/notas-credito': placeholderPage('Notas crédito'),
};
const notFound = placeholderPage('Página no encontrada', 'Revisa la dirección o vuelve al inicio.');

const currentPath = () => location.hash.replace(/^#/, '') || '/';

export function startRouter(container) {
  const render = () => {
    const path = currentPath();
    (routes[path] ?? notFound)(container);
    setActiveNav(path);
    window.scrollTo(0, 0);
    container.focus({ preventScroll: true });
  };
  window.addEventListener('hashchange', render);
  render();
}
